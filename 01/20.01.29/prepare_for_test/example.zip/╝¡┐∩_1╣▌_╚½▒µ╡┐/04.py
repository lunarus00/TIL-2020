# 파일명 및 함수명을 변경하지 마시오.
# 추가 모듈이나 패키지를 import 할 수 없습니다.
def q4(word):
    """
    아래에 코드를 작성하시오.
    word는 소문자로만 구성 되어있습니다.
    word에 s, a, f, y가 들어 있는지 여부를 Boolean 값으로 반환하세요.
    """


# 실행 결과를 확인하기 위한 코드입니다. 수정하지 마시오.
if __name__ == '__main__':
    print(q4('fish'))
    print(q4('united'))
    print(q4('galaxy'))